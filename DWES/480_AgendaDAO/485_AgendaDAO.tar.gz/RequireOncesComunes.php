<?php

// Este PHP tiene los requires que necesitan los PHP comunes de la aplicación.

require_once "utilidades.php";
require_once "sesiones.php";
require_once "dao.php";
require_once "clases.php";
