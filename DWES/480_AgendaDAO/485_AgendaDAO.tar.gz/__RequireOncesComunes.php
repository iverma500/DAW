<?php

// Este PHP tiene los requires que necesitan los PHP comunes de la aplicación.

require_once "_Varios.php";
require_once "_Clases.php";
require_once "_DAO.php";
require_once "_Sesion.php";
require_once "_Plantillas.php";