<?php

require_once "_com/DAO.php";

// TODO ###
echo json_encode(DAO::categoriaObtenerTodas());